<div id="sidebar">
    <h2>Menu</h2>
    <ul class="sidemenu">				
        <li><a href="../index.php">Home</a></li>
		 <li id="movie_up" ><a href="#">Upload Movies</a></li>
        <li id="song_up" ><a href="#">Upload Songs</a></li>
        <li id="post_up" ><a href="#">Upload Post</a></li>
        <li id="img_up" ><a href="#">Upload Images</a></li>
        
    </ul>	
</div>