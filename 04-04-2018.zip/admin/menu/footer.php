<div id="footer">
    <p>
        &copy; 2016 <strong>prajapati</strong> 
        		
    </p>
</div>
