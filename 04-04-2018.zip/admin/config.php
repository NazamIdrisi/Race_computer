<?php 

$server="localhost:3306";
define("DB_DATABASE", "httprace_com");
define("DB_USERNAME", "httprace_raghu");
define("DB_PASSWORD", "anujkrp@121");


$conn = mysqli_connect($server, $user, $password,$dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>