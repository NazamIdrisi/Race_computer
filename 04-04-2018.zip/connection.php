<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'httprace_race');
define('DB_PASSWORD', 'anujkrp@121');
define('DB_DATABASE', 'httprace_race');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>