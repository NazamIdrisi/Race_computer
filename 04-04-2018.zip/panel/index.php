<html>
    <head>
        <title>Race Computer Institute</title>
    </head>
    <body style="margin:0 0 0 0;">
        <iframe src="http://std1.yourphpscript.com/view/login.php" style="height:200%;width:100%;" scrolling="no"></iframe>
    </body>
</html>